
// Experiment-2 Write a program to compute CRC code for the polynomials CRC-12, CRC-16 and CRC CCIP

// Source Code:
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to perform CRC calculation
void computeCRC(int *data, int dataLength, int *divisor, int divLength, int *remainder) {
    int i, j;
    // Initialize remainder with the data
    
    system("cls");
    for (i = 0; i < divLength - 1; i++) {
        remainder[i] = data[i];
    }

    for (i = divLength - 1; i < dataLength; i++) {
        if (remainder[0] == 1) {
            // Perform XOR operation with the divisor
            for (j = 0; j < divLength; j++) {
                remainder[j] = remainder[j] ^ divisor[j];
            }
        }
        // Shift the remainder to the left and bring in the next bit from data
        for (j = 0; j < divLength - 1; j++) {
            remainder[j] = remainder[j + 1];
        }
        remainder[divLength - 1] = data[i];
    }

    // Copy the final remainder to the result
    for (i = 0; i < divLength - 1; i++) {
        remainder[i] = remainder[i + 1];
    }
}

// Function to print binary array
void printArray(int *arr, int length) {
    for (int i = 0; i < length; i++) {
        printf("%d", arr[i]);
    }
    printf("\n");
}

int main(void) {
    int data[50], divisor[16], remainder[16];
    int dataLength, divLength, i;
    char input[50];

    // Input data
    printf("Enter the data (0s and 1s only): ");
    fgets(input, sizeof(input), stdin);
    dataLength = strlen(input) - 1; // Exclude the newline character
    for (i = 0; i < dataLength; i++) {
        data[i] = (input[i] == '1') ? 1 : 0;
    }

    // Input divisor
    printf("Enter the divisor (0s and 1s only): ");
    fgets(input, sizeof(input), stdin);
    divLength = strlen(input) - 1; // Exclude the newline character
    for (i = 0; i < divLength; i++) {
        divisor[i] = (input[i] == '1') ? 1 : 0;
    }

    // Append zeros to data
    for (i = dataLength; i < dataLength + divLength - 1; i++) {
        data[i] = 0;
    }
    dataLength += divLength - 1;

    // Compute CRC
    computeCRC(data, dataLength, divisor, divLength, remainder);

    // Display the remainder (CRC)
    printf("CRC (remainder): ");
    printArray(remainder, divLength - 1);

    // Append CRC to the original data to create the data to be sent
    printf("Data to be sent: ");
    for (i = 0; i < dataLength - divLength + 1; i++) {
        printf("%d", data[i]);
    }
    printArray(remainder, divLength - 1);

    return 0;
}