
//      Experiment-1-A: Implement the data link layer farming methods such as character,
    //        character-stuffing

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    int i = 0, j = 0, n, pos;
    char a[20], b[50], ch;

    system("cls");
    printf("Enter string: ");
    scanf("%s", a);

    n = strlen(a);
    
    printf("Enter position: ");
    scanf("%d", &pos);

    if (pos > n || pos < 1) {
        printf("Invalid position, Enter again:\n");
        scanf("%d", &pos);
    }

    printf("Enter the character: ");
    scanf(" %c", &ch); // Note the space before %c to skip any leading whitespace

    b[j++] = 'd';
    b[j++] = 'l';
    b[j++] = 'e';
    b[j++] = 's';
    b[j++] = 't';
    b[j++] = 'x';

    while (i < n) {
        if (i == pos - 1) {
            b[j++] = 'd';
            b[j++] = 'l';
            b[j++] = 'e';
            b[j++] = ch;
            b[j++] = 'd';
            b[j++] = 'l';
            b[j++] = 'e';
        }
        if (a[i] == 'd' && a[i+1] == 'l' && a[i+2] == 'e') {
            b[j++] = 'd';
            b[j++] = 'l';
            b[j++] = 'e';
        }
        b[j++] = a[i++];
    }

    b[j++] = 'd';
    b[j++] = 'l';
    b[j++] = 'e';
    b[j++] = 'e';
    b[j++] = 't';
    b[j++] = 'x';
    b[j] = '\0';

    printf("Frame after stuffing: ");
    printf("%s\n", b);

    return 0;
}
