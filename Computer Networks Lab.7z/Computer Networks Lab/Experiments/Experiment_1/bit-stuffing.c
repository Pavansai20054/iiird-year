
//    Experiment-1-B: Implement the data link layer farming methods such as character,
            //  bit-stuffing

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    int a[20], b[30], i, j, k, count, n;

    // Input frame length
    system("cls");
    printf("Enter frame length: ");
    scanf("%d", &n);

    // Input frame
    printf("Enter input frame (0's & 1's only):\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    i = 0;
    count = 0;
    j = 0;

    // Bit stuffing
    while (i < n) {
        if (a[i] == 1) {
            b[j] = a[i];
            count++;
            if (count == 5) {
                j++;
                b[j] = 0; // Insert a 0 after five consecutive 1's
                count = 0; // Reset the count
            }
        } else {
            b[j] = a[i];
            count = 0; // Reset the count if a 0 is encountered
        }
        i++;
        j++;
    }

    // Output stuffed frame
    printf("After stuffing, the frame is: ");
    for (i = 0; i < j; i++) {
        printf("%d", b[i]);
    }
    printf("\n");

    return 0;
}