
// Experiment- 8: Write a program for congestion control using Leaky bucket algorithm

// Source Code
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#define NOF_PACKETS 10
int my_rand(int a) {
    int rn = (rand() % 10) % a;
    return rn == 0 ? 1 : rn;
}

int main() {
    srand(time(NULL)); // seed the random number generator

    system("cls");
    int bucket_size = 5; // bucket size in packets
    int leak_rate = 2; // leak rate in packets per second
    int packet_arrival_rate = 3; // packet arrival rate in packets per second

    int packets_in_bucket = 0; // number of packets currently in the bucket
    int packets_dropped = 0; // number of packets dropped due to bucket overflow

    int i;
    for (i = 0; i < NOF_PACKETS; i++) {
        // simulate packet arrival
        int packets_arrived = my_rand(packet_arrival_rate);
        printf("Packet arrival: %d packets\n", packets_arrived);

        // add packets to bucket
        packets_in_bucket += packets_arrived;

        // leak packets from bucket
        int packets_leaked = my_rand(leak_rate);
        printf("Packet leak: %d packets\n", packets_leaked);
        packets_in_bucket -= packets_leaked;

        // check for bucket overflow
        if (packets_in_bucket > bucket_size) {
            int packets_to_drop = packets_in_bucket - bucket_size;
            packets_dropped += packets_to_drop;
            packets_in_bucket = bucket_size;
            printf("Bucket overflow! Dropped %d packets\n", packets_to_drop);
        }

        printf("Packets in bucket: %d\n", packets_in_bucket);
        printf("Packets dropped: %d\n", packets_dropped);
    }

    return 0;
}