
// Experiment-5 : Take an example subnet of hosts and obtain a broadcast tree for the subnet.

// Source Code
#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int a[MAX][MAX], n;

void adj(int k);

int main()
{
    int i, j, root;
    system("cls");
    printf("Enter the number of nodes: ");
    scanf("%d", &n);
    
    if (n > MAX) {
        printf("The number of nodes exceeds the maximum allowed (%d).\n", MAX);
        return 1;
    }
    
    printf("Enter the adjacency matrix (0 or 1):\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("Enter connection between %d and %d: ", i, j);
            scanf("%d", &a[i][j]);
        }
    }
    
    printf("Enter the root node (0 to %d): ", n-1);
    scanf("%d", &root);
    
    if (root < 0 || root >= n) {
        printf("Invalid root node.\n");
        return 1;
    }
    
    adj(root);
    
    return 0;
}

void adj(int k)
{
    int i, j;
    printf("Adjacent nodes of root node %d.\n", k);
    
    // Print adjacent nodes
    for (j = 0; j < n; j++) {
        if (a[k][j] == 1 || a[j][k] == 1) {
            printf("%d\t", j);
        }
    }
    printf("\n");

    // Print nodes that are not directly connected to the root
    printf("Nodes not directly connected to the root node %d.\n", k);
    for (i = 0; i < n; i++) {
        if (i != k && (a[k][i] == 0 && a[i][k] == 0)) {
            printf("%d\t", i);
        }
    }
    printf("\n");
}