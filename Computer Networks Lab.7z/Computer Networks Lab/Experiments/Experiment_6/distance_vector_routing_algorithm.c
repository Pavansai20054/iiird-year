
// Experiment-6 : Implement  distance  vector  routing  algorithm  for  obtaining  routing  tables  at  each node.

// Source Code

#include <stdio.h>
#include <stdlib.h>

void flush_input() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
}

int main() {
    int i, j, nv, sn, noadj, edel[20], tdel[20][20], min;
    char sv, adver[20], ch;

    system("cls");
    printf("\n ENTER THE NO. OF VERTICES: ");
    scanf("%d", &nv);

    printf("\n ENTER THE SOURCE VERTEX NUMBER AND NAME: ");
    scanf("%d", &sn);
    flush_input();  // Flush the input buffer
    sv = getchar();

    printf("\n ENTER NO. OF ADJACENT VERTICES TO VERTEX %c: ", sv);
    scanf("%d", &noadj);

    for (i = 0; i < noadj; i++) {
        printf("\n ENTER TIME DELAY AND NODE NAME: ");
        scanf("%d %c", &edel[i], &adver[i]);
        flush_input();  // Flush after reading the char
    }

    for (i = 0; i < noadj; i++) {
        printf("\n ENTER THE TIME DELAY FROM %c TO ALL OTHER NODES: ", adver[i]);
        for (j = 0; j < nv; j++) {
            scanf("%d", &tdel[i][j]);
        }
    }

    printf("\n DELAY VIA--VERTEX \n");
    for (i = 0; i < nv; i++) {
        min = 1000;
        ch = 0;
        for (j = 0; j < noadj; j++) {
            if (min > (tdel[j][i] + edel[j])) {
                min = tdel[j][i] + edel[j];
                ch = adver[j];
            }
        }
        if (i != sn - 1)
            printf("\n%d %c", min, ch);
        else
            printf("\n0 -");
    }

    return 0;
}